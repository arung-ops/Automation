import { test, expect } from '@playwright/test';

const LOGIN_URL = 'https://hq.nyovate.dev/login';

test.describe('NyoHQ - Login Page', () => {

  test.beforeEach(async ({ page }) => {
    await page.goto(LOGIN_URL);
    await page.waitForLoadState('domcontentloaded');
  });


  test('TC01 - Verify NyoHQ login page is displayed', async ({ page }) => {

    await expect(
      page.getByRole('heading', {
        name: 'Sign in to NyoHQ'
      })
    ).toBeVisible();
    page.getByRole('link',{
        name:'QA sign-in (email code)'
    }).click();
    // page.getByRole('button',{
    //     name:'Continue with Google'
    // }).click();


    await expect(page).toHaveURL(LOGIN_URL);
  });
});